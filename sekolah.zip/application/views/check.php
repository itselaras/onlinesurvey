<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap-theme.min.css">
    
<!-- dev URL -->
<script src="https://rawgit.com/unconditional/jquery-table2excel/master/src/jquery.table2excel.js"></script>
    
<!-- !!! use this URL for production:
<script src="https://cdn.rawgit.com/unconditional/jquery-table2excel/master/src/jquery.table2excel.js"></script>
-->
    


<div class="row">
  <div class="col-md-2">
    <a class="btn btn-default" id="export-btn">Export</a>
  </div>
  <div class="col-md-10"></div>
</div>

    <table id="resultsTable" data-tableName="Test Table 2" class="table table-bordered">
        <thead>
            <tr class="noExl"><td>This shouldn't get exported</td><td>This shouldn't get exported either</td></tr>
            <tr><td>This Should get exported as a header</td><td>This should too</td></tr>
        </thead>
        <tbody>
            <tr><td>data1a</td><td>data1b</td></tr>
            <tr><td>data2a</td><td>data2b</td></tr>
        </tbody>
        <tfoot>
            <tr><td colspan="2">This footer spans 2 cells</td></tr>
        </tfoot>
    </table>
    
    <script>
        jQuery(document).ready(function() {
    
    $('#export-btn').on('click', function(e){
        e.preventDefault();
        ResultsToTable();
    });
    
    function ResultsToTable(){    
        $("#resultsTable").table2excel({
            exclude: ".noExl",
            name: "Results"
        });
    }
});


    </script>
    
    
    