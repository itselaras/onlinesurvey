<!-- ========== Left Sidebar Start ========== -->
            <div class="left side-menu">
                <div class="slimscroll-menu" id="remove-scroll">

                    <!--- Sidemenu -->
                    <div id="sidebar-menu">
                        <!-- Left Menu Start -->
                        <ul class="metismenu" id="side-menu">
                            <li class="menu-title">Main</li>
                            <li>
                                <a href="<?php echo site_url('welcome/user_admin');?>" class="waves-effect"><i class="mdi mdi-account"></i><span> Peserta </span></a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('welcome/admin');?>" class="waves-effect">
                                    <i class="mdi mdi-view-dashboard"></i><span> Sekolah </span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo site_url('welcome/report_admin');?>" class="waves-effect"><i class="mdi mdi-calendar-check"></i><span> Report</span></a>
                            </li>

                            

                        </ul>

                    </div>
                    <!-- Sidebar -->
                    <div class="clearfix"></div>

                </div>
                <!-- Sidebar -left -->
                
            </div>
            <!-- Left Sidebar End -->