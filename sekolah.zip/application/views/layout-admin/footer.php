                <footer class="footer">
                        © 2021 Crafted with <i class="mdi mdi-heart text-danger"></i> by SMI IT Team</span>.
                </footer>


        </div>
        <!-- END wrapper -->
            

        <!-- jQuery  -->
        <script src="<?php echo base_url('assets-2/js/jquery.min.js')?>"></script>
        <script src="<?php echo base_url('assets-2/js/bootstrap.bundle.min.js')?>"></script>
        <script src="<?php echo base_url('assets-2/js/metisMenu.min.js')?>"></script>
        <script src="<?php echo base_url('assets-2/js/jquery.slimscroll.js')?>"></script>
        <script src="<?php echo base_url('assets-2/js/waves.min.js')?>"></script>


        <script src="<?php echo base_url('assets-2/plugins/jquery-sparkline/jquery.sparkline.min.js');?>"></script>

        <!-- Plugins js -->
        <script src="<?php echo base_url('assets-2/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/select2/js/select2.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/bootstrap-filestyle/js/bootstrap-filestyle.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js');?>"></script>
        
        <!-- Required datatable js -->
        <script src="<?php echo base_url('assets-2/plugins/datatables/jquery.dataTables.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/dataTables.bootstrap4.min.js');?>"></script>
        
        <!-- Buttons examples -->
        
        <script src="<?php echo base_url('assets-2/plugins/datatables/dataTables.buttons.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/buttons.bootstrap4.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/jszip.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/pdfmake.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/vfs_fonts.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/buttons.html5.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/buttons.print.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/buttons.colVis.min.js');?>"></script>
        <!-- Responsive examples -->
        <script src="<?php echo base_url('assets-2/plugins/datatables/dataTables.responsive.min.js');?>"></script>
        <script src="<?php echo base_url('assets-2/plugins/datatables/responsive.bootstrap4.min.js');?>"></script>

        <!-- Datatable init js -->
        <script src="<?php echo base_url('assets-2/pages/datatable.init.js');?>"></script>

        <!-- Plugins Init js -->
        <script src="<?php echo base_url('assets-2/pages/form-advanced.js')?>"></script>
        
        <!-- App js -->
        <script src="<?php echo base_url('assets-2/js/app.js')?>"></script>
        
        <!--j2query-->
        <script src="https://rawgit.com/unconditional/jquery-table2excel/master/src/jquery.table2excel.js"></script>
        


    </body>

</html>