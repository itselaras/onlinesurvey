<footer id="footer">
 
            <div class="container">
       <div class="row">
        <div class="col-md-3 col-sm-6" style="margin: 0 auto; float: none;"> 
                    <div class="footerwidget"> 
                             <h4 class="text-center">Kontak</h4> 
                <div class="contact-info"> 
                <i class="fa fa-map-marker"></i> Jalan Ketintang Madya 80 Surabaya<br>
                <i class="fa fa-phone"></i> 031 - 8285737<br>
                 <i class="fa fa-envelope-o"></i> hrd@selarasmitraintegra.com<br>
                 <i class="fa fa-globe"></i> www.selarasmitraintegra.com
                </div> 
                    </div><!-- end widget --> 
        </div>
    </div>
    <div class="row">
                <div class="col-md-4">
                    
                </div>
                <div class="social col-md-4 text-center">
                    <a target="_blank" href="https://www.instagram.com/selarasmitraintegra/"><img class="img-fluid" style="width: 50px;" src="<?php echo base_url('assets/images/instagram.png')?>"></a>
                    <a target="_blank" href="https://twitter.com/selaras_mitra"><img class="img-fluid" style="width: 50px;" src="<?php echo base_url('assets/images/twitter.png')?>"></a>
                </div> 
                <div class="col-md-4 panel">
                    <div class="panel-body" style="margin-top: 70px;">
                        <p class="text-right">
                            Copyright &copy; 2020. SMI IT Team
                        </p>
                    </div>
                </div>
    </div>
    </div>
        </footer>
    
        <!-- JavaScript libs are placed at the end of the document so the pages load faster -->
        <script src="<?php echo base_url('assets/js/modernizr-latest.js')?>"></script> 
        <script type='text/javascript' src="<?php echo base_url('assets/js/fancybox/jquery.fancybox.pack.js')?>"></script>
        
        <script type='text/javascript' src="<?php echo base_url('assets/js/jquery.mobile.customized.min.js')?>"></script>
        <script type='text/javascript' src="<?php echo base_url('assets/js/jquery.easing.1.3.js')?>"></script> 
        <script type='text/javascript' src="<?php echo base_url('assets/js/camera.min.js')?>"></script> 
        <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script> 
        <script src="<?php echo base_url('assets/js/custom.js')?>"></script>
        <script>
            jQuery(function(){
                
                jQuery('#camera_wrap_4').camera({
                    transPeriod: 500,
                    time: 3000,
                    height: '600',
                    loader: 'false',
                    pagination: true,
                    thumbnails: false,
                    hover: false,
                    playPause: false,
                    navigation: false,
                    opacityOnGrid: false,
                    imagePath: 'assets/images/'
                });
    
            });
          
        </script>
        <script>
                                $(function(){

                                $('input[id^="A"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="A"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="B"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="B"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="C"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="C"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="D"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="D"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="E"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="E"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="F"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="F"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="G"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="G"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="H"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="H"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                                  
                                  $('input[id^="I"]').change(function() {
                                
                                    var $current = $(this);
                                
                                    $('input[id^="I"]').each(function() {
                                        if ($(this).val() == $current.val() && $(this).attr('id') != $current.attr('id') && $(this).val() !== '')
                                        {
                                            alert('Tidak boleh memasukkan nilai yang sama!');
                                            $current.val("");
                                        }
                                
                                    });
                                  });
                            });
        </script>
        
<script>
    $('.selector').keyup(function () {
        this.value = this.value.replace(/^0*(?:[^1-9]?|1[^0-2]|[2-9][0-9])$/g, '');
});
</script>



    
        
    </body>
</html>